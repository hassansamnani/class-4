package com.example.class4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    EditText username;
    EditText password;
    EditText email;
    EditText phone;
    CheckBox cb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.textView);
        username = findViewById(R.id.editText);
        password = findViewById(R.id.editText2);
        email = findViewById(R.id.editText3);
        phone = findViewById(R.id.editText4);
        cb = findViewById(R.id.checkBox);
    }

    public void onClickSubmitButton(View v){
        String name = username.getText().toString();
        String pass = password.getText().toString();
        String emailid = email.getText().toString();
        String ph = phone.getText().toString();
        boolean isError = false;

        if(name != null && name.equalsIgnoreCase("")){
            username.setError("Enter Valid name");
            isError = true;
        }
        if(pass != null && name.equalsIgnoreCase("")){
            password.setError("Enter Valid email");
            isError = true;
        }
        if(ph != null && name.equalsIgnoreCase("")){
            phone.setError("Enter Valid password");
            isError = true;
        }
        if(emailid != null && name.equalsIgnoreCase("")){
            email.setError("Enter Valid password");
            isError = true;
        }

        if(!cb.isChecked()){
            cb.setTextColor(Color.RED);
        }


    }
}
